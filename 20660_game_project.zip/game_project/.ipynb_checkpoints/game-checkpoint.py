import pygame
import os
from player import Player_action
from setting import WIN_HEIGHT, WIN_WIDTH
# load image
BACKGROUND_IMAGE = pygame.image.load(os.path.join("images", "Map.png"))


class Game:
    def __init__(self):
        self.win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        self.bg_image = pygame.transform.scale(BACKGROUND_IMAGE, (WIN_WIDTH, WIN_HEIGHT))
        self.player = Player_action()
        
    def draw(self):
        # draw background
        self.win.blit(self.bg_image, (0, 0))
        # draw player
        self.player.draw(self.win)
        pygame.display.update()

    def update(self):
        game_quit = False
        # event loop
        mouse_x, mouse_y = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_quit = True
                return game_quit
            # player press action
            if event.type == pygame.KEYDOWN:
                if(event.key == pygame.K_w):
                    self.player.jump()
            key_pressed= pygame.key.get_pressed()        
            key_pressed_2= pygame.key.get_pressed()
            #if(key_pressed[pygame.K_w] or key_pressed_2[pygame.K_w]):
               # self.player.jump()
            if (key_pressed[pygame.K_u] or key_pressed_2[pygame.K_u]):
                self.player.turn_L()
            elif (key_pressed[pygame.K_i] or key_pressed_2[pygame.K_i]):
                  self.player.turn_R()                
            if (key_pressed[pygame.K_a] or key_pressed_2[pygame.K_a]):
                self.player.move_L()
            elif (key_pressed[pygame.K_d] or key_pressed_2[pygame.K_d]):
                  self.player.move_R()
            if(key_pressed[pygame.K_s] or key_pressed_2[pygame.K_s]):
                self.player.down=True
            else:
                self.player.down=False
            # player click action
            if event.type == pygame.MOUSEBUTTONDOWN:
                pass
            
        self.player.update()    
        return game_quit

