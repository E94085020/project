import pygame
import os
from setting import WIN_WIDTH

pygame.init()
PLAYER_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))
PLAYER_IMAGE_L = pygame.transform.flip(PLAYER_IMAGE,True,False)
class Player:
    def __init__(self):
        self.image=pygame.transform.scale(PLAYER_IMAGE,(80,100))
        self.rect=self.image.get_rect()
        self.x=500
        self.y=500
        self.rect.center=(self.x,self.y)
        self.hp=100
        self.max_hp=100
        self.jumping=False
        self.jump_time=0
    def draw(self, win):
        # draw enemy
        win.blit(self.image,self.rect)   
    def is_jumping(self):
        if(self.jumping):
            if(self.jump_time<=25):
                self.y-=3   
            else:
                self.y+=3
            self.jump_time+=1    
            if(self.jump_time==51):
                self.jumping = False
                self.jump_time=0
    def is_down(self,down):
        if(self.jumping==False): 
            if(down):
                self.y=510
            else:
                self.y=500            

    
class Player_action:
    def __init__(self):
        self.face_to_right=True
        self.down=False
        self.player=Player()
    def update(self):
        self.player.is_down(self.down)
        self.player.is_jumping()
        self.player.rect.centerx=self.player.x
        self.player.rect.centery=self.player.y
    def draw(self,win):
        self.player.draw(win)
        
    def move_L(self):
        if(self.player.x>=10):
            self.player.x-=2 
            
    def move_R(self):
        if(self.player.x<=WIN_WIDTH-10):
            self.player.x+=2  
            
    def jump(self):
        self.player.jumping =True
        
    def turn_R(self):
        self.face_to_right=True
        self.player.image=pygame.transform.scale(PLAYER_IMAGE,(80,100))

    def turn_L(self):
        self.face_to_right=False
        self.player.image=pygame.transform.scale(PLAYER_IMAGE_L,(80,100))        
        
 
    def get_player(self):
        return self.player